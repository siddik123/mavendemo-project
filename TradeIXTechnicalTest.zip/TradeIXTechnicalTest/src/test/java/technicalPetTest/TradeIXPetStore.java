package technicalPetTest;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import io.restassured.http.ContentType;
import petAPI.PostPayLoad;
import petAPI.PutPayload;

import org.testng.annotations.Test;
/*
 * TradeIX Technical test
 * Author: Mohammad Siddik
 * Email: siddikdublin@gmail.com
 * Mobile: 0892166089
 */
public class TradeIXPetStore {
	/*
	 * Verify Pet Details Created with correct Data using POST Method
	 * and verify status code 200 
	 */
	@Test(priority=1)
	public void createPet()
	{
		given()
			.contentType(ContentType.JSON)
			//upload POST method body using PostPayload.getPostData()
			.body(PostPayLoad.getPostData())
			.when()
				.post("https://petstore.swagger.io/v2/pet")
			.then()
			.statusCode(200);
		
	}
	
	/*
	 * Verify Pet Details Created with correct Data using GET Method
	 * and verify status code 200 
	 * and with all correct Data
	 */
	@Test(priority=2)
	public void getPetRecord(){
		given()
			.when()
				.get("https://petstore.swagger.io/v2/pet/101")
			.then()
				.assertThat()
				.statusCode(200)
				.and()
				.contentType(ContentType.JSON)
				.and()
				//Verify id =101
				.body("id",equalTo(101))
				.and()
				//Verify category id =10
				.body("category.id",equalTo(10))
				.and()
				//Verify category name =Guide
				.body("category.name",equalTo("Guide"))
				.and()
				//Verify name =Tom
				.body("name",equalTo("Tom"))
				.and()
				//Verify PgotoUrls =http://www.pet.ie/image
				.body("photoUrls[0]",equalTo("http://www.pet.ie/image"))
				.and()
				//Verify tags id =11
				.body("tags[0].id",equalTo(11))
				.and()
				//Verify tags name =Guidedog
				.body("tags[0].name",equalTo("Guidedog"))
				.and()
				//Verify status =available
				.body("status",equalTo("available"));
	}
	/*
	 * Update Pet Name Tom with Poppy using PUT Method
	 * and verify status code 200 
	 * and name = Poppy
	 */
	@Test(priority=3)
	public void updatePetName()
	{
		given()
			.contentType(ContentType.JSON)
			//upload put method body using PutPayload.getPutData() 
			.body(PutPayload.getPutData())
			.when()
				.put("https://petstore.swagger.io/v2/pet")
			.then()
			//Verify Status code 200
			.statusCode(200)
			.and()
			//Verify Name update with Poppy with same ID 101
			.body("name",equalTo("Poppy"));
		
	}
	
	/*
	 * Delete record from the pet store using Delete Method
	 * and verify status code 200 
	 */
	@Test(priority=4)
	public void deletePetRecord(){
		given()
			.when()
				.delete("https://petstore.swagger.io/v2/pet/101")
				.then()
				.assertThat()
				//Verify Status Code 200
				.statusCode(200);
	}

}
