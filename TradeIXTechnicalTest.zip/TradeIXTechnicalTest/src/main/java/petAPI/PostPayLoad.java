package petAPI;

public class PostPayLoad {

	//POST body
	public static String getPostData()
	{
	
		String createPet = "{"+
			    "\"id\": 101,"+
			    "\"category\": {"+
			        "\"id\": 10,"+
			        "\"name\": \"Guide\""+
			    "},"+
			    "\"name\": \"Tom\","+
			    "\"photoUrls\": ["+
			        "\"http://www.pet.ie/image\""+
			    "],"+
			    "\"tags\": ["+
			        "{"+
			            "\"id\": 11,"+
			            "\"name\": \"Guidedog\""+
			        "}"+
			    "],"+
			    "\"status\": \"available\""+
			"}";
		
		
		return createPet;
	}
	
}
