package petAPI;

public class PutPayload {
	//PUT body for update pet name
	public static String getPutData()
	{
		String updatePet = "{"+
			    "\"id\": 101,"+
			    "\"category\": {"+
			        "\"id\": 10,"+
			        "\"name\": \"Guide\""+
			    "},"+
			    "\"name\": \"Poppy\","+
			    "\"photoUrls\": ["+
			        "\"http://www.pet.ie/image\""+
			    "],"+
			    "\"tags\": ["+
			        "{"+
			            "\"id\": 11,"+
			            "\"name\": \"Guidedog\""+
			        "}"+
			    "],"+
			    "\"status\": \"available\""+
			"}";
				
			return updatePet;
		}
}
